FAHIM GRAPHIC DESIGN — GITHUB PAGES FIX

Upload BOTH the index.html file and the assets folder to the ROOT of your GitHub repository.
Keep the folder structure exactly:
  index.html
  assets/
    image-....webp / image-....jpeg
    video-....mp4

Do not upload only index.html: it now references the extracted media in assets/.
On GitHub: open the repository -> Add file -> Upload files -> upload index.html and the entire assets folder contents (you can drag the assets folder into the upload area in a desktop browser, or upload a ZIP's extracted contents). Commit changes to the branch/folder configured in Settings -> Pages.
GitHub Pages usually publishes from main / (root) or the selected /docs folder. If Pages is set to /docs, place index.html and assets/ inside docs/ instead.
After commit, allow a few minutes and refresh the site. If old content remains, hard-refresh or clear browser cache.
